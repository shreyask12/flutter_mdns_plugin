#import <Flutter/Flutter.h>

@interface FlutterMdnsPlugin : NSObject<FlutterPlugin, NSNetServiceBrowserDelegate, NSNetServiceDelegate>
@end
